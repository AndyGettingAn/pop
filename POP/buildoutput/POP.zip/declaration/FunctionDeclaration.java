package declaration;

public class FunctionDeclaration extends SubcallDeclaration {
    public FunctionDeclaration() {
        super();
    }

    public FunctionDeclaration(String varName) {
        super(varName);
    }
}
